package com.charlezz.finalarchitecture.feature.remote

data class Post(val id:Long, val userId:Long, val title:String, val body:String)