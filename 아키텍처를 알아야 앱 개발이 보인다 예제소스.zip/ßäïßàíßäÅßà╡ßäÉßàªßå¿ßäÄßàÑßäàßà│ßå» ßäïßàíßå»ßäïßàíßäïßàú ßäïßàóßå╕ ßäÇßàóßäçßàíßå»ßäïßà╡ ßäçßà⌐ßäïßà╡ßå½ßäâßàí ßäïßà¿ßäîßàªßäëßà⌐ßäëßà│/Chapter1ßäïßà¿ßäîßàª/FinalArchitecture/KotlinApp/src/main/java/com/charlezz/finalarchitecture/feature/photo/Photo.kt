package com.charlezz.finalarchitecture.feature.photo

data class Photo(val name:String, val path:String)