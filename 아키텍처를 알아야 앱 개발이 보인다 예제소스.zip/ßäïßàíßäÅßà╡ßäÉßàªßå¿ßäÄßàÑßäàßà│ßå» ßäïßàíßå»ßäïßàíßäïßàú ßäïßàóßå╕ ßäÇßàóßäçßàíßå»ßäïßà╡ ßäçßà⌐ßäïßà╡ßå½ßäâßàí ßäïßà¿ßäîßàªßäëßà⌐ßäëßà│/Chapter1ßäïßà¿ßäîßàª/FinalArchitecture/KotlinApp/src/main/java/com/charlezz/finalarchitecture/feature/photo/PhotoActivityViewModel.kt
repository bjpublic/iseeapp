package com.charlezz.finalarchitecture.feature.photo

import androidx.lifecycle.ViewModel

class PhotoActivityViewModel: ViewModel(){

}