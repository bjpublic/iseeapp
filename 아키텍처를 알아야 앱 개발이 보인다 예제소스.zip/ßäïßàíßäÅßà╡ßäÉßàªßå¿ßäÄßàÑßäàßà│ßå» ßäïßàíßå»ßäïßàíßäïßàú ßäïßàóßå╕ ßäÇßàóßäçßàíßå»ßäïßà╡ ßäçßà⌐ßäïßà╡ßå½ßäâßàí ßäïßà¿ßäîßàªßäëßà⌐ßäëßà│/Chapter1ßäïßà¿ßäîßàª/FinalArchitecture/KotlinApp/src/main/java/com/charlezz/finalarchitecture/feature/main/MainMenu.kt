package com.charlezz.finalarchitecture.feature.main

enum class MainMenu{
    PERSON_ACTIVITY,
    POST_ACTIVITY,
    PREFERENCE_ACTIVITY,
    PHOTO_ACTIVITY
}