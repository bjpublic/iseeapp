package com.charlezz.javaapp.feature;

import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

public class MainViewModel extends ViewModel {
    @Inject
    public MainViewModel(){

    }
}
