package com.charlezz.dagger2.dagger.test.cafe;

public class CoffeeBean {

}