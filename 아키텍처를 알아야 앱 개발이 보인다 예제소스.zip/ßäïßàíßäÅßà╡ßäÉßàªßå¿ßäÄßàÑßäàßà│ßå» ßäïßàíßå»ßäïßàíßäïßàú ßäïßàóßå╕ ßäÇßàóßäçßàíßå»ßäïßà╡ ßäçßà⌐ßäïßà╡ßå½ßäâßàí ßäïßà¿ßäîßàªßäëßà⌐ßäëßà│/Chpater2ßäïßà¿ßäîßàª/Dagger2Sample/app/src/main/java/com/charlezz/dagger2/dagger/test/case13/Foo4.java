package com.charlezz.dagger2.dagger.test.case13;

import javax.inject.Inject;

public class Foo4 {
    @Inject
    public String str;
    @Inject
    public Integer integer;
}