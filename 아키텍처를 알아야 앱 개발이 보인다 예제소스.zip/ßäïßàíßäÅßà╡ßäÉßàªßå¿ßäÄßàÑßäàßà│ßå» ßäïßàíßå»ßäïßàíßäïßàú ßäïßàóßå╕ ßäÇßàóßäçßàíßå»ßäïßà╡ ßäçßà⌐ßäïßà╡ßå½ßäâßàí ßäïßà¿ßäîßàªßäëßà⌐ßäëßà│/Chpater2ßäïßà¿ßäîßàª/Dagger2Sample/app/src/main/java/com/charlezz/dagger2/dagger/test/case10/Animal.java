package com.charlezz.dagger2.dagger.test.case10;

public enum Animal {
    CAT, DOG;
}