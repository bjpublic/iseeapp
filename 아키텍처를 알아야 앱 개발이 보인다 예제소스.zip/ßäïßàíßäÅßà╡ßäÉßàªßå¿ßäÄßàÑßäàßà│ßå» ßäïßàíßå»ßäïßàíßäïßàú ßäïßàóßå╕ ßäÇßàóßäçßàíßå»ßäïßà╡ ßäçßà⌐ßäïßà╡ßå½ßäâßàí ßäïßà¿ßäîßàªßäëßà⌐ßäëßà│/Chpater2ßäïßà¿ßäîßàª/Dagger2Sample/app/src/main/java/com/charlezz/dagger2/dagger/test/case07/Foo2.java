package com.charlezz.dagger2.dagger.test.case07;

import javax.inject.Inject;

public class Foo2 {

    @Inject
    public String str;

    @Inject
    public Foo2(){

    }

}