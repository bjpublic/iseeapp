# ReflectionTest
[리플렉션](https://www.charlezz.com/?p=756), [다이나믹 프록시](http://www.charlezz.com/?p=759)에 대한 설명과 예제입니다.
