package com.example.java;

public interface Foo {
   void bar();
}