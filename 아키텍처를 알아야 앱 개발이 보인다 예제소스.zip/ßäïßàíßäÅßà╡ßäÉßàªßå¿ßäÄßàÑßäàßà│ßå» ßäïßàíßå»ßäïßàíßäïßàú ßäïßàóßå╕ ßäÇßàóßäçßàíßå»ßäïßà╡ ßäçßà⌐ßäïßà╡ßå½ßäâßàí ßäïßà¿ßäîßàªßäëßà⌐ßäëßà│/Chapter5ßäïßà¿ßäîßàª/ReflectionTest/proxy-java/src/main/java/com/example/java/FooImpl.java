package com.example.java;

public class FooImpl implements Foo {

   @Override
   public void bar(){
      System.out.println("Hello World");
   }

}