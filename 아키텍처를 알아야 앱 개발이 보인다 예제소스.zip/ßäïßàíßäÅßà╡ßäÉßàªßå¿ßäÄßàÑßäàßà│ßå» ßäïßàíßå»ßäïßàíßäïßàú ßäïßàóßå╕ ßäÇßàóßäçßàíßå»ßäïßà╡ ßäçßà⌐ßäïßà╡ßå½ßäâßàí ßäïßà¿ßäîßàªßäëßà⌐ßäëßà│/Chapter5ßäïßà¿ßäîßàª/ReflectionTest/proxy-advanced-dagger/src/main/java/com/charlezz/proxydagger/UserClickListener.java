package com.charlezz.proxydagger;

public interface UserClickListener {
    void onUserClick(User user);
}