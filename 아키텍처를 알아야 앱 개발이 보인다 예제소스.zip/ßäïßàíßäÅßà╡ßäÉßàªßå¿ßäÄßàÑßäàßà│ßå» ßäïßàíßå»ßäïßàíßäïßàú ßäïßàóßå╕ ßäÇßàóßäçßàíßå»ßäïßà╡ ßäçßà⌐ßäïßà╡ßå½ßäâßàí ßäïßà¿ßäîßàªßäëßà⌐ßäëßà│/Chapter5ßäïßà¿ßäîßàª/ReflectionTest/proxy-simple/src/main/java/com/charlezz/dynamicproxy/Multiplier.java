package com.charlezz.dynamicproxy;

public interface Multiplier {
    int multiply(int value);
}
