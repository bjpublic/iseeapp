package com.charlezz.arch.data.entity;

public class Company {
    private String name;
    private String catchPhrase;
    private String bs;

    public String getName() {
        return name;
    }
    public String getCatchPhrase() {
        return catchPhrase;
    }
    public String getBs() {
        return bs;
    }

}
