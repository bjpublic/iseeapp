package com.charlezz.arch.data.entity;

public class Geo {
    private String lat;
    private String lng;

    public String getLat() {
        return lat;
    }
    public String getLng() {
        return lng;
    }
}
